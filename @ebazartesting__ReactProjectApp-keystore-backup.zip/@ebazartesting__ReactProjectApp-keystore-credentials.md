# Android Upload Keystore Credentials

These credentials are used in conjunction with your Android upload keystore file to sign your app for distribution.

## Credential Values

- Android upload keystore password: 68ad26b53f8052541f9c6704926d1a08
- Android key alias: 08a23e940dc0dca447d0be4fc5cd57bc
- Android key password: a6c8d25c44a1419c0f856e6a523035a3
      